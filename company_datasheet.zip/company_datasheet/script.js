const data = [
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/1/24",
    "Value date": "7/2/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "NEFT",
    Department: "Sales",
    Location: "Mumbai",
    " Amount ": " 232,323.00 ",
    "Receiver Name": "Reliance Ind",
    "Receiver Business type": "Manufacturer",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/1/24",
    "Value date": "7/3/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Worli",
    "Product Type": "CHEQUE",
    Department: "Sales",
    Location: "Mumbai",
    " Amount ": " 343,343.00 ",
    "Receiver Name": "Reliance Ind",
    "Receiver Business type": "Manufacturer",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/4/24",
    "Value date": "7/4/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Worli",
    "Product Type": "IMPS",
    Department: "Sales",
    Location: "Mumbai",
    " Amount ": " 3,232,323.00 ",
    "Receiver Name": "Reliance Ind",
    "Receiver Business type": "Manufacturer",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/5/24",
    "Value date": "7/6/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "NEFT",
    Department: "Sales",
    Location: "Mumbai",
    " Amount ": " 2,424,344.00 ",
    "Receiver Name": "NCC Ltd",
    "Receiver Business type": "Construction",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/7/24",
    "Value date": "7/8/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "NEFT",
    Department: "Marketing",
    Location: "Pune",
    " Amount ": " 343,423.00 ",
    "Receiver Name": "NCC Ltd",
    "Receiver Business type": "Construction",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/8/24",
    "Value date": "7/8/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Worli",
    "Product Type": "NEFT",
    Department: "Marketing",
    Location: "Pune",
    " Amount ": " 2,323,253.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/10/24",
    "Value date": "7/11/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "RTGS",
    Department: "Marketing",
    Location: "Pune",
    " Amount ": " 5,354,343.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/20/24",
    "Value date": "7/21/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "RTGS",
    Department: "Marketing",
    Location: "Pune",
    " Amount ": " 3,434,323.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "7/30/24",
    "Value date": "7/30/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Worli",
    "Product Type": "RTGS",
    Department: "Marketing",
    Location: "Pune",
    " Amount ": " 2,323,534.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/1/24",
    "Value date": "8/2/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "IMPS",
    Department: "Branding",
    Location: "Goa",
    " Amount ": " 5,334,343.00 ",
    "Receiver Name": "BHEL",
    "Receiver Business type": "Eletrucal",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/7/24",
    "Value date": "8/9/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Worli",
    "Product Type": "CHEQUE",
    Department: "Branding",
    Location: "Goa",
    " Amount ": " 434,344.00 ",
    "Receiver Name": "BHEL",
    "Receiver Business type": "Eletrucal",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/10/24",
    "Value date": "8/12/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Worli",
    "Product Type": "CHEQUE",
    Department: "Branding",
    Location: "Goa",
    " Amount ": " 323,253.00 ",
    "Receiver Name": "IOL",
    "Receiver Business type": "Oil and Natural Gas",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/15/24",
    "Value date": "8/16/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Worli",
    "Product Type": "CHEQUE",
    Department: "Branding",
    Location: "Goa",
    " Amount ": " 3,434,343.00 ",
    "Receiver Name": "IOL",
    "Receiver Business type": "Oil and Natural Gas",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/20/24",
    "Value date": "8/22/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Worli",
    "Product Type": "CHEQUE",
    Department: "Branding",
    Location: "Goa",
    " Amount ": " 2,323,434.00 ",
    "Receiver Name": "IOL",
    "Receiver Business type": "Oil and Natural Gas",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/24/24",
    "Value date": "8/27/24",
    "Days Delay for fund realization": "3",
    "Remitter Branch": "Worli",
    "Product Type": "CHEQUE",
    Department: "Branding",
    Location: "Goa",
    " Amount ": " 3,232,534.00 ",
    "Receiver Name": "Reliance Ind",
    "Receiver Business type": "Manufacturer",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "8383920323",
    "Upload Date": "8/30/24",
    "Value date": "8/30/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Worli",
    "Product Type": "RTGS",
    Department: "Admin",
    Location: "Chennai",
    " Amount ": " 5,334,353.00 ",
    "Receiver Name": "Reliance Ind",
    "Receiver Business type": "Manufacturer",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/3/24",
    "Value date": "7/3/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Fort",
    "Product Type": "RTGS",
    Department: "Admin",
    Location: "Chennai",
    " Amount ": " 2,333,634.00 ",
    "Receiver Name": "Reliance Ind",
    "Receiver Business type": "Manufacturer",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/4/24",
    "Value date": "7/4/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Fort",
    "Product Type": "RTGS",
    Department: "Admin",
    Location: "Chennai",
    " Amount ": " 4,545,454.00 ",
    "Receiver Name": "NCC Ltd",
    "Receiver Business type": "Construction",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/6/24",
    "Value date": "7/7/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "CHEQUE",
    Department: "Admin",
    Location: "Chennai",
    " Amount ": " 4,543,434.00 ",
    "Receiver Name": "NCC Ltd",
    "Receiver Business type": "Construction",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/7/24",
    "Value date": "7/8/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "CHEQUE",
    Department: "Legal",
    Location: "Delhi",
    " Amount ": " 3,232,243.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/9/24",
    "Value date": "8/10/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "IMPS",
    Department: "Legal",
    Location: "Delhi",
    " Amount ": " 232,325.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/22/24",
    "Value date": "7/23/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "NEFT",
    Department: "Legal",
    Location: "Delhi",
    " Amount ": " 4,435,334.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/24/24",
    "Value date": "7/26/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Fort",
    "Product Type": "CHEQUE",
    Department: "Legal",
    Location: "Delhi",
    " Amount ": " 434,434.00 ",
    "Receiver Name": "IDFC Finance Ltd",
    "Receiver Business type": "Finance",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/28/24",
    "Value date": "7/29/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "NEFT",
    Department: "Legal",
    Location: "Delhi",
    " Amount ": " 5,343,435.00 ",
    "Receiver Name": "BHEL",
    "Receiver Business type": "Eletrucal",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "7/30/24",
    "Value date": "7/30/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Fort",
    "Product Type": "RTGS",
    Department: "HR",
    Location: "Mumbai",
    " Amount ": " 4,345,354.00 ",
    "Receiver Name": "BHEL",
    "Receiver Business type": "Eletrucal",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/4/24",
    "Value date": "8/4/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Fort",
    "Product Type": "RTGS",
    Department: "HR",
    Location: "Mumbai",
    " Amount ": " 323,232.00 ",
    "Receiver Name": "IOL",
    "Receiver Business type": "Oil and Natural Gas",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/5/24",
    "Value date": "8/5/24",
    "Days Delay for fund realization": "0",
    "Remitter Branch": "Fort",
    "Product Type": "RTGS",
    Department: "HR",
    Location: "Mumbai",
    " Amount ": " 533,434.00 ",
    "Receiver Name": "IOL",
    "Receiver Business type": "Oil and Natural Gas",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/9/24",
    "Value date": "8/10/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "NEFT",
    Department: "HR",
    Location: "Mumbai",
    " Amount ": " 6,453,422.00 ",
    "Receiver Name": "IOL",
    "Receiver Business type": "Oil and Natural Gas",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/10/24",
    "Value date": "8/12/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Fort",
    "Product Type": "CHEQUE",
    Department: "HR",
    Location: "Mumbai",
    " Amount ": " 243,453.00 ",
    "Receiver Name": "Alpa Labs",
    "Receiver Business type": "Pharma",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/13/24",
    "Value date": "8/14/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "IMPS",
    Department: "Sales",
    Location: "Kochi",
    " Amount ": " 5,353,433.00 ",
    "Receiver Name": "Alpa Labs",
    "Receiver Business type": "Pharma",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/15/24",
    "Value date": "8/17/24",
    "Days Delay for fund realization": "2",
    "Remitter Branch": "Fort",
    "Product Type": "CHEQUE",
    Department: "Sales",
    Location: "Kochi",
    " Amount ": " 3,436,353.00 ",
    "Receiver Name": "Alpa Labs",
    "Receiver Business type": "Pharma",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/22/24",
    "Value date": "8/23/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "IMPS",
    Department: "Sales",
    Location: "Kochi",
    " Amount ": " 343,423.00 ",
    "Receiver Name": "Alpa Labs",
    "Receiver Business type": "Pharma",
    "Parent Account number": "",
  },
  {
    "Parent Acct No": "13379202032",
    "Remitter A/c No": "4343534343",
    "Upload Date": "8/29/24",
    "Value date": "8/30/24",
    "Days Delay for fund realization": "1",
    "Remitter Branch": "Fort",
    "Product Type": "IMPS",
    Department: "Sales",
    Location: "Kochi",
    " Amount ": " 3,533,433.00 ",
    "Receiver Name": "Alpa Labs",
    "Receiver Business type": "Pharma",
    "Parent Account number": "",
  },
];

const aggregatedSubscriptions = data.reduce((acc, item) => {
  const department = item["Department"];
  const amountStr = item[" Amount "];
  const amount = parseFloat(amountStr.replace(/,/g, "").trim());

  if (acc[department]) {
    acc[department].amount += amount;
  } else {
    acc[department] = {
      id: item["Remitter A/c No"],
      title: department,
      amount: amount,
    };
  }

  return acc;
}, {});

const subscriptions = Object.values(aggregatedSubscriptions);

console.log(subscriptions);

let lineChart, barChart, pieChart, areaChart;

function renderCharts(selectedCategories) {
  const filteredData = subscriptions.filter((sub) =>
    selectedCategories.includes(sub.title)
  );
  const categories = filteredData.map((sub) => sub.title);
  const seriesData = filteredData.map((sub) => sub.amount);

  const totalSpend = seriesData.reduce((acc, curr) => acc + curr, 0);
  const formattedTotalSpend = `₹${totalSpend.toLocaleString()}`;
  document.getElementById("totalSpendDisplay").innerText = formattedTotalSpend;

  // Line Chart
  if (!lineChart) {
    lineChart = new ApexCharts(document.querySelector("#lineChart"), {
      chart: { type: "line", height: 300 },
      series: [{ name: "Spend", data: seriesData }],
      xaxis: { categories, title: { text: "Departments" } },
      yaxis: { title: { text: "Amount (₹)" } },
    });

    barChart = new ApexCharts(document.querySelector("#barChart"), {
      chart: { type: "bar", height: 300 },
      series: [{ name: "Spend", data: seriesData }],
      xaxis: { categories, title: { text: "Departments" } },
      yaxis: { title: { text: "Amount (₹)" } },
      plotOptions: {
        bar: {
          dataLabels: { position: "top" },
        },
      },
      dataLabels: {
        enabled: true,
        offsetY: -20,
        formatter: function (val) {
          return `₹${val.toLocaleString()}`;
        },
        style: { fontSize: "12px", colors: ["grey"] },
      },
      colors: ["#666cff"],
    });

    pieChart = new ApexCharts(document.querySelector("#pieChart"), {
      chart: { type: "pie", height: 300 },
      series: seriesData,
      labels: categories,
    });

    areaChart = new ApexCharts(document.querySelector("#areaChart"), {
      chart: { type: "area", height: 200 },
      series: [{ name: "Spend", data: seriesData }],
      xaxis: { categories, title: { text: "Departments" } },
      yaxis: { title: { text: "Amount (₹)" } },
    });

    lineChart.render();
    barChart.render();
    pieChart.render();
    areaChart.render();
  } else {
    lineChart.updateOptions({
      series: [{ name: "Spend", data: seriesData }],
      xaxis: { categories },
    });

    barChart.updateOptions({
      series: [{ name: "Spend", data: seriesData }],
      xaxis: { categories },
    });

    pieChart.updateOptions({
      series: seriesData,
      labels: categories,
    });

    areaChart.updateOptions({
      series: [{ name: "Spend", data: seriesData }],
      xaxis: { categories },
    });
  }

  // Render 3D Pie Chart using Highcharts
  render3DPieChart(categories, seriesData);
}

function render3DPieChart(categories, seriesData) {
  Highcharts.chart("3dPieChartContainer", {
    chart: {
      type: "pie",
      options3d: {
        enabled: true,
        alpha: 45,
        beta: 0,
        depth: 250,
        viewDistance: 25,
      },
    },
    title: {
      text: "",
    },
    tooltip: {
      pointFormat: "{series.name}: <b>₹{point.y:,.0f}</b>",
    },
    plotOptions: {
      pie: {
        depth: 35,
        dataLabels: {
          formatter: function () {
            return (
              this.point.name + ": ₹" + Highcharts.numberFormat(this.point.y, 0)
            );
          },
        },
      },
    },
    series: [
      {
        name: "Spending",
        data: categories.map((cat, index) => ({
          name: cat,
          y: seriesData[index],
        })),
      },
    ],
    credits: {
      enabled: false,
    },
  });
}

const dropdownToggle = document.getElementById("dropdownToggle");
const dropdownMenu = document.getElementById("dropdownMenu");

dropdownToggle.addEventListener("click", function () {
  console.log("hello");
  dropdownMenu.classList.toggle("open-box");
});

dropdownMenu.addEventListener("change", function () {
  const selectedOptions = Array.from(
    this.querySelectorAll("input:checked")
  ).map((input) => input.value);
  renderCharts(selectedOptions);
});

renderCharts(subscriptions.map((sub) => sub.title));

//city wise
const aggregatedLocations = data.reduce((acc, item) => {
  const location = item["Location"];
  const amountStr = item[" Amount "];
  const amount = parseFloat(amountStr.replace(/,/g, "").trim());

  if (acc[location]) {
    acc[location].amount += amount;
  } else {
    acc[location] = {
      id: item["Remitter A/c No"],
      title: location,
      amount: amount,
    };
  }

  return acc;
}, {});

const cityData = Object.values(aggregatedLocations);

console.log(cityData);

// Create city charts
let cityLineChart, cityBarChart, cityPieChart, cityAreaChart;

function renderCityCharts(selectedCities) {
  const filteredCityData = cityData.filter((city) =>
    selectedCities.includes(city.title)
  );
  const cityCategories = filteredCityData.map((city) => city.title);
  const citySeriesData = filteredCityData.map((city) => city.amount);

  if (!cityLineChart) {
    cityLineChart = new ApexCharts(document.querySelector("#cityLineChart"), {
      chart: { type: "line", height: 200 },
      series: [{ name: "Spend", data: citySeriesData }],
      xaxis: { categories: cityCategories, title: { text: "Cities" } },
      yaxis: { title: { text: "Amount (₹)" } },
    });

    cityBarChart = new ApexCharts(document.querySelector("#cityBarChart"), {
      chart: { type: "bar", height: 300 },
      series: [{ name: "Spend", data: citySeriesData }],
      xaxis: { categories: cityCategories, title: { text: "Cities" } },
      yaxis: { title: { text: "Amount (₹)" } },
      plotOptions: {
        bar: {
          dataLabels: { position: "top" },
        },
      },
      dataLabels: {
        enabled: true,
        offsetY: -20,
        formatter: function (val) {
          return `₹${val.toLocaleString()}`;
        },
        style: { fontSize: "12px", colors: ["grey"] },
      },
      colors: ["#666cff"],
    });

    cityPieChart = new ApexCharts(document.querySelector("#cityPieChart"), {
      chart: { type: "pie", height: 300 },
      series: citySeriesData,
      labels: cityCategories,
    });

    cityAreaChart = new ApexCharts(document.querySelector("#cityAreaChart"), {
      chart: { type: "area", height: 200 },
      series: [{ name: "Spend", data: citySeriesData }],
      xaxis: { categories: cityCategories, title: { text: "Cities" } },
      yaxis: { title: { text: "Amount (₹)" } },
    });

    cityLineChart.render();
    cityBarChart.render();
    cityPieChart.render();
    cityAreaChart.render();
  } else {
    cityLineChart.updateOptions({
      series: [{ name: "Spend", data: citySeriesData }],
      xaxis: { categories: cityCategories },
    });

    cityBarChart.updateOptions({
      series: [{ name: "Spend", data: citySeriesData }],
      xaxis: { categories: cityCategories },
    });

    cityPieChart.updateOptions({
      series: citySeriesData,
      labels: cityCategories,
    });

    cityAreaChart.updateOptions({
      series: [{ name: "Spend", data: citySeriesData }],
      xaxis: { categories: cityCategories },
    });
  }

  // Render 3D Pie Chart for Cities
  render3DCityPieChart(cityCategories, citySeriesData);
}

// Function to render 3D Pie Chart for Cities
function render3DCityPieChart(categories, seriesData) {
  Highcharts.chart("3dCityPieChartContainer", {
    chart: {
      type: "pie",
      options3d: {
        enabled: true,
        alpha: 45,
        beta: 0,
        depth: 250,
        viewDistance: 25,
      },
    },
    title: {
      text: "",
    },
    tooltip: {
      pointFormat: "{series.name}: <b>₹{point.y:,.0f}</b>",
    },
    plotOptions: {
      pie: {
        depth: 35,
        dataLabels: {
          formatter: function () {
            return (
              this.point.name + ": ₹" + Highcharts.numberFormat(this.point.y, 0)
            );
          },
        },
      },
    },
    series: [
      {
        name: "Spending",
        data: categories.map((cat, index) => ({
          name: cat,
          y: seriesData[index],
        })),
      },
    ],
    credits: {
      enabled: false, // Disable the watermark
    },
  });
}

// Event listener for city dropdown toggle
const dropdownToggleCity = document.getElementById("dropdownToggleCity");
const dropdownMenuCity = document.getElementById("dropdownMenuCity");

dropdownToggleCity.addEventListener("click", function () {
  console.log("hello");
  dropdownMenuCity.parentElement.classList.toggle("open");
});

// Event listener for city checkbox change
dropdownMenuCity.addEventListener("change", function () {
  const selectedCityOptions = Array.from(
    this.querySelectorAll("input:checked")
  ).map((input) => input.value);
  renderCityCharts(selectedCityOptions);
  updateCityTotalSpend(selectedCityOptions);
});

// Function to update total spend display for selected cities
function updateCityTotalSpend(selectedCities) {
  const filteredCityData = cityData.filter((city) =>
    selectedCities.includes(city.title)
  );
  const totalSpend = filteredCityData.reduce(
    (acc, city) => acc + city.amount,
    0
  );
  const totalSpendDisplay = document.getElementById("displayTotalSpend");
  totalSpendDisplay.innerText = `₹${totalSpend.toLocaleString()}`;
}

// Initial render with all cities selected
renderCityCharts(cityData.map((city) => city.title));
updateCityTotalSpend(cityData.map((city) => city.title));

// Function to aggregate amounts by department -----------------------------------------------------------------------------------
// Your combined data for cities and departments
// Combined data for cities and departments




const averages = {};

// Step 1: Calculate total days delay and count for each product type
data.forEach((transaction) => {
  const productType = transaction["Product Type"];
  const daysDelay = parseInt(transaction["Days Delay for fund realization"]);

  if (!averages[productType]) {
    averages[productType] = { totalDelay: 0, count: 0 };
  }

  averages[productType].totalDelay += daysDelay;
  averages[productType].count += 1;
});

// Step 2: Calculate averages for days delay for each product type
const averageDaysDelay = {};

for (const productType in averages) {
  const totalDelay = averages[productType].totalDelay;
  const count = averages[productType].count;

  averageDaysDelay[productType] = {
    "Average Days Delay": (totalDelay / count).toFixed(2), // Keep two decimal places
  };
}

// Output the result
console.log(averageDaysDelay);

// Store the chart variables
let averageDelayChart;
let averageDelayBarChart;
let averageDelayPieChart;
let averageDelayAreaChart;
let averageDelay3DPieChart;

// Function to calculate average delays for selected transactions
function calculateAverageDelays(selectedTransactions) {
  const transactionDelayMap = {};

  selectedTransactions.forEach((transaction) => {
    transactionDelayMap[transaction] = { totalDelay: 0, count: 0 };
  });

  Object.keys(averageDaysDelay).forEach((productType) => {
    if (selectedTransactions.includes(productType)) {
      const { "Average Days Delay": averageDelay } =
        averageDaysDelay[productType];
      transactionDelayMap[productType].totalDelay += parseFloat(averageDelay);
      transactionDelayMap[productType].count += 1;
    }
  });

  const averageDelays = [];
  const categories = [];

  for (const [key, value] of Object.entries(transactionDelayMap)) {
    if (value.count > 0) {
      categories.push(key);
      averageDelays.push(value.totalDelay / value.count);
    }
  }

  return { categories, averageDelays };
}

// Render delay charts (line, bar, pie, area)
function renderAverageDelayChart(selectedTransactions) {
  const { categories, averageDelays } =
    calculateAverageDelays(selectedTransactions);

  // Render 3D Pie Chart for average delays
  render3DAverageDelayPieChart(categories, averageDelays);

  if (!averageDelayChart) {
    averageDelayChart = new ApexCharts(
      document.querySelector("#delayLineChart"),
      {
        chart: { type: "line", height: 200 },
        series: [{ name: "Average Delay", data: averageDelays }],
        xaxis: { categories, title: { text: "Transaction Types" } },
        yaxis: { title: { text: "Average Delay (Days)" } },
      }
    );
    averageDelayChart.render();
  } else {
    averageDelayChart.updateOptions({
      series: [{ name: "Average Delay", data: averageDelays }],
      xaxis: { categories },
    });
  }
}

function renderAverageDelayBarChart(selectedTransactions) {
  const { categories, averageDelays } =
    calculateAverageDelays(selectedTransactions);

  if (!averageDelayBarChart) {
    averageDelayBarChart = new ApexCharts(
      document.querySelector("#delayBarChart"),
      {
        chart: { type: "bar", height: 300 },
        series: [{ name: "Average Delay", data: averageDelays }],
        xaxis: { categories, title: { text: "Transaction Types" } },
        yaxis: { title: { text: "Average Delay (Days)" } },
        fill: { opacity: 0.5 },
        colors: ["#666cff"],
      }
    );
    averageDelayBarChart.render();
  } else {
    averageDelayBarChart.updateOptions({
      series: [{ name: "Average Delay", data: averageDelays }],
      xaxis: { categories },
    });
  }
}

function renderAverageDelayPieChart(selectedTransactions) {
  const { categories, averageDelays } =
    calculateAverageDelays(selectedTransactions);

  if (!averageDelayPieChart) {
    averageDelayPieChart = new ApexCharts(
      document.querySelector("#delayPieChart"),
      {
        chart: { type: "pie", height: 300 },
        series: averageDelays,
        labels: categories,
      }
    );
    averageDelayPieChart.render();
  } else {
    averageDelayPieChart.updateOptions({
      series: averageDelays,
      labels: categories,
    });
  }
}

// Function to render the area chart
function renderAverageDelayAreaChart(selectedTransactions) {
  const { categories, averageDelays } =
    calculateAverageDelays(selectedTransactions);

  if (!averageDelayAreaChart) {
    averageDelayAreaChart = new ApexCharts(
      document.querySelector("#delayAreaChart"),
      {
        chart: { type: "area", height: 200 },
        series: [{ name: "Average Delay", data: averageDelays }],
        xaxis: { categories, title: { text: "Transaction Types" } },
        yaxis: { title: { text: "Average Delay (Days)" } },
        fill: { opacity: 0.7 },
        colors: ["#666cff"],
      }
    );
    averageDelayAreaChart.render();
  } else {
    averageDelayAreaChart.updateOptions({
      series: [{ name: "Average Delay", data: averageDelays }],
      xaxis: { categories },
    });
  }
}

// Function to render the 3D Pie Chart for Average Delays
function render3DAverageDelayPieChart(categories, averageDelays) {
  Highcharts.chart("3dDelayPieChartContainer", {
    chart: {
      type: "pie",
      options3d: {
        enabled: true,
        alpha: 45,
        beta: 0,
        depth: 250,
        viewDistance: 25,
      },
    },
    title: {
      text: "",
    },
    tooltip: {
      pointFormat: "{series.name}: <b>{point.y:.2f} days</b>",
    },
    plotOptions: {
      pie: {
        depth: 35,
        dataLabels: {
          formatter: function () {
            return this.point.name + ": " + this.point.y.toFixed(2) + " days";
          },
        },
      },
    },
    series: [
      {
        name: "Average Delay",
        data: categories.map((cat, index) => ({
          name: cat,
          y: averageDelays[index],
        })),
      },
    ],
    credits: {
      enabled: false, // Disable the watermark
    },
  });
}

// Function to update total delay display for selected transactions
function updateTotalDelayDisplay(selectedTransactions) {
  const { categories, averageDelays } =
    calculateAverageDelays(selectedTransactions);
  const totalAverageDelay =
    averageDelays.reduce((acc, delay) => acc + delay, 0) /
      averageDelays.length || 0;

  const totalDelayDisplay = document.getElementById("totalDelayDisplay");
  totalDelayDisplay.innerText = `${totalAverageDelay.toFixed(2)} days`;
}

// Event listener for transaction checkbox change
function updateCharts() {
  const selectedTransactions = Array.from(
    document.querySelectorAll(".transaction-checkboxes input:checked")
  ).map((input) => input.value);

  renderAverageDelayChart(selectedTransactions);
  renderAverageDelayBarChart(selectedTransactions);
  renderAverageDelayPieChart(selectedTransactions);
  renderAverageDelayAreaChart(selectedTransactions);
  updateTotalDelayDisplay(selectedTransactions);
}

// Initial render with all transactions selected
updateCharts();
const Data = [
  { date: "7/1/2024", receiver: "Reliance Ind", amount: 232323 },
  { date: "7/1/2024", receiver: "Reliance Ind", amount: 343343 },
  { date: "7/4/2024", receiver: "Reliance Ind", amount: 3232323 },
  { date: "7/5/2024", receiver: "NCC Ltd", amount: 2424344 },
  { date: "7/7/2024", receiver: "NCC Ltd", amount: 343423 },
  { date: "7/8/2024", receiver: "IDFC Finance Ltd", amount: 2323253 },
  { date: "7/10/2024", receiver: "IDFC Finance Ltd", amount: 5354343 },
  { date: "7/20/2024", receiver: "IDFC Finance Ltd", amount: 3434323 },
  { date: "7/30/2024", receiver: "IDFC Finance Ltd", amount: 2323534 },
  { date: "8/1/2024", receiver: "BHEL", amount: 5334343 },
  { date: "8/7/2024", receiver: "BHEL", amount: 434344 },
  { date: "8/10/2024", receiver: "IOL", amount: 323253 },
  { date: "8/15/2024", receiver: "IOL", amount: 3434343 },
  { date: "8/20/2024", receiver: "IOL", amount: 2323434 },
  { date: "8/24/2024", receiver: "Reliance Ind", amount: 3232534 },
  { date: "8/30/2024", receiver: "Reliance Ind", amount: 5334353 },
  { date: "7/3/2024", receiver: "Reliance Ind", amount: 2333634 },
  { date: "7/4/2024", receiver: "NCC Ltd", amount: 4545454 },
  { date: "7/6/2024", receiver: "NCC Ltd", amount: 4543434 },
  { date: "7/7/2024", receiver: "IDFC Finance Ltd", amount: 3232243 },
  { date: "7/9/2024", receiver: "IDFC Finance Ltd", amount: 232325 },
  { date: "7/22/2024", receiver: "IDFC Finance Ltd", amount: 4435334 },
  { date: "7/24/2024", receiver: "IDFC Finance Ltd", amount: 434434 },
  { date: "7/28/2024", receiver: "BHEL", amount: 5343435 },
  { date: "7/30/2024", receiver: "BHEL", amount: 4345354 },
  { date: "8/4/2024", receiver: "IOL", amount: 323232 },
  { date: "8/5/2024", receiver: "IOL", amount: 533434 },
  { date: "8/9/2024", receiver: "IOL", amount: 6453422 },
  { date: "8/10/2024", receiver: "Alpa Labs", amount: 243453 },
  { date: "8/13/2024", receiver: "Alpa Labs", amount: 5353433 },
  { date: "8/15/2024", receiver: "Alpa Labs", amount: 3436353 },
  { date: "8/22/2024", receiver: "Alpa Labs", amount: 343423 },
  { date: "8/29/2024", receiver: "Alpa Labs", amount: 3533433 },
];

// Chart variables
let remittanceBarChart;
let remittanceLineChart;
let remittanceAreaChart;
let remittancePieChart;
let remittance3DPieChart; // Variable for the 3D Pie Chart

// Function to generate unique dates for dropdown
function populateDateDropdown() {
  const uniqueDates = Array.from(new Set(Data.map((item) => item.date))); // Get unique dates
  const dropdownMenuDate = document.getElementById("dropdownMenuDate");

  // Clear previous checkboxes if any
  dropdownMenuDate.innerHTML = "";

  // Populate dropdown with checkboxes for each unique date
  uniqueDates.forEach((date) => {
    const label = document.createElement("label");
    label.innerHTML = `<input type="checkbox" value="${date}" checked /> ${date}`;
    dropdownMenuDate.appendChild(label);
  });
}

// Render the remittance charts
function renderRemittanceCharts(selectedDates, selectedReceivers) {
  const amountMap = new Map();
  let totalRemittance = 0;

  selectedReceivers.forEach((receiver) => {
    amountMap.set(receiver, 0);
  });

  Data.forEach((item) => {
    if (
      selectedDates.includes(item.date) &&
      selectedReceivers.includes(item.receiver)
    ) {
      amountMap.set(item.receiver, amountMap.get(item.receiver) + item.amount);
      totalRemittance += item.amount; // Calculate total remittance
    }
  });

  const categories = Array.from(amountMap.keys());
  const seriesData = Array.from(amountMap.values());

  // Update total remittance display
  document.getElementById(
    "totalRemittanceDisplay"
  ).innerText = `Total Remittance: ₹${totalRemittance.toLocaleString()}`;

  // Render Bar Chart
  if (!remittanceBarChart) {
    remittanceBarChart = new ApexCharts(
      document.querySelector("#remittanceBarChart"),
      {
        chart: { type: "bar", height: 300 },
        series: [{ name: "Amount", data: seriesData }],
        xaxis: { categories, title: { text: "Receiver" } },
        yaxis: { title: { text: "Amount (₹)" } },
        colors: ["#666cff"],
      }
    );
    remittanceBarChart.render();
  } else {
    remittanceBarChart.updateOptions({
      series: [{ name: "Amount", data: seriesData }],
      xaxis: { categories },
    });
  }

  // Render Line Chart
  if (!remittanceLineChart) {
    remittanceLineChart = new ApexCharts(
      document.querySelector("#remittanceLineChart"),
      {
        chart: { type: "line", height: 300 },
        series: [{ name: "Amount", data: seriesData }],
        xaxis: { categories, title: { text: "Receiver" } },
        yaxis: { title: { text: "Amount (₹)" } },
        colors: ["#ff5722"],
      }
    );
    remittanceLineChart.render();
  } else {
    remittanceLineChart.updateOptions({
      series: [{ name: "Amount", data: seriesData }],
      xaxis: { categories },
    });
  }

  // Render Area Chart
  if (!remittanceAreaChart) {
    remittanceAreaChart = new ApexCharts(
      document.querySelector("#remittanceAreaChart"),
      {
        chart: { type: "area", height: 300 },
        series: [{ name: "Amount", data: seriesData }],
        xaxis: { categories, title: { text: "Receiver" } },
        yaxis: { title: { text: "Amount (₹)" } },
        colors: ["#666cff"],
      }
    );
    remittanceAreaChart.render();
  } else {
    remittanceAreaChart.updateOptions({
      series: [{ name: "Amount", data: seriesData }],
      xaxis: { categories },
    });
  }

  // Render Pie Chart
  if (!remittancePieChart) {
    remittancePieChart = new ApexCharts(
      document.querySelector("#remittancePieChart"),
      {
        chart: { type: "pie", height: 300 },
        series: seriesData,
        labels: categories,
        colors: ["#ffeb3b", "#ff9800", "#f44336", "#2196f3"],
      }
    );
    remittancePieChart.render();
  } else {
    remittancePieChart.updateOptions({
      series: seriesData,
      labels: categories,
    });
  }

  // Render 3D Pie Chart
  render3DRemittancePieChart(categories, seriesData);
}

// Function to render the 3D Pie Chart for Remittances
function render3DRemittancePieChart(categories, seriesData) {
  Highcharts.chart("3dRemittPieChartContainer", {
    chart: {
      type: "pie",
      options3d: {
        enabled: true,
        alpha: 45,
        beta: 0,
        depth: 250,
      },
    },
    title: {
      text: "",
    },
    tooltip: {
      pointFormat: "{series.name}: <b>{point.y:.2f} ₹</b>",
    },
    plotOptions: {
      pie: {
        depth: 35,
        dataLabels: {
          formatter: function () {
            return this.point.name + ": " + this.point.y.toFixed(0);
          },
        },
      },
    },
    series: [
      {
        name: "Remittance Amount",
        data: categories.map((cat, index) => ({
          name: cat,
          y: seriesData[index],
        })),
      },
    ],
    credits: {
      enabled: false, // Disable the watermark
    },
  });
}

// Event listeners for dropdowns and checkboxes
document.addEventListener("DOMContentLoaded", () => {
  // Populate the date dropdown on page load
  populateDateDropdown();

  const dropdownToggleDate = document.getElementById("dropdownToggleDate");
  const dropdownMenuDate = document.getElementById("dropdownMenuDate");

  dropdownToggleDate.addEventListener("click", function () {
    dropdownMenuDate.parentElement.classList.toggle("open");
  });


  const dropdownMenuReceiver = document.getElementById("dropdownMenuReceiver");
  
  const dropdownToggleReceiver = document.getElementById("dropdownToggleReceiver");
  dropdownToggleReceiver.addEventListener("click", function () {
    dropdownMenuReceiver.parentElement.classList.toggle("open");
  });

  dropdownMenuDate.addEventListener("change", function () {
    const selectedDateOptions = Array.from(
      this.querySelectorAll("input[type='checkbox']:checked")
    ).map((input) => input.value);

    const selectedReceiverOptions = Array.from(
      dropdownMenuReceiver.querySelectorAll("input[type='checkbox']:checked")
    ).map((input) => input.value);

    renderRemittanceCharts(selectedDateOptions, selectedReceiverOptions);
  });

  dropdownMenuReceiver.addEventListener("change", function () {
    const selectedDateOptions = Array.from(
      dropdownMenuDate.querySelectorAll("input[type='checkbox']:checked")
    ).map((input) => input.value);

    const selectedReceiverOptions = Array.from(
      this.querySelectorAll("input[type='checkbox']:checked")
    ).map((input) => input.value);

    renderRemittanceCharts(selectedDateOptions, selectedReceiverOptions);
  });

  // Initial render with default selections
  renderRemittanceCharts(
    Array.from(
      dropdownMenuDate.querySelectorAll("input[type='checkbox']:checked")
    ).map((input) => input.value),
    Array.from(
      dropdownMenuReceiver.querySelectorAll("input[type='checkbox']:checked")
    ).map((input) => input.value)
  );
});
