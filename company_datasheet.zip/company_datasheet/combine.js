// Sample combined data array
const combinedData = [];

// Additional data
const additionalData = [
  {
    Department: "Sales",
    Location: "Mumbai",
    Amount: 232323,
    ReceiverName: "Reliance Ind",
  },
  {
    Department: "Sales",
    Location: "Mumbai",
    Amount: 343343,
    ReceiverName: "Reliance Ind",
  },
  {
    Department: "Sales",
    Location: "Mumbai",
    Amount: 3232323,
    ReceiverName: "Reliance Ind",
  },
  {
    Department: "Sales",
    Location: "Mumbai",
    Amount: 2424344,
    ReceiverName: "NCC Ltd",
  },
  {
    Department: "Marketing",
    Location: "Pune",
    Amount: 343423,
    ReceiverName: "NCC Ltd",
  },
  {
    Department: "Marketing",
    Location: "Pune",
    Amount: 2323253,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Marketing",
    Location: "Pune",
    Amount: 5354343,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Marketing",
    Location: "Pune",
    Amount: 3434323,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Marketing",
    Location: "Pune",
    Amount: 2323534,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Branding",
    Location: "Goa",
    Amount: 5334343,
    ReceiverName: "BHEL",
  },
  {
    Department: "Branding",
    Location: "Goa",
    Amount: 434344,
    ReceiverName: "BHEL",
  },
  {
    Department: "Branding",
    Location: "Goa",
    Amount: 323253,
    ReceiverName: "IOL",
  },
  {
    Department: "Branding",
    Location: "Goa",
    Amount: 3434343,
    ReceiverName: "IOL",
  },
  {
    Department: "Branding",
    Location: "Goa",
    Amount: 2323434,
    ReceiverName: "IOL",
  },
  {
    Department: "Branding",
    Location: "Goa",
    Amount: 3232534,
    ReceiverName: "Reliance Ind",
  },
  {
    Department: "Admin",
    Location: "Chennai",
    Amount: 5334353,
    ReceiverName: "Reliance Ind",
  },
  {
    Department: "Admin",
    Location: "Chennai",
    Amount: 2333634,
    ReceiverName: "Reliance Ind",
  },
  {
    Department: "Admin",
    Location: "Chennai",
    Amount: 4545454,
    ReceiverName: "NCC Ltd",
  },
  {
    Department: "Admin",
    Location: "Chennai",
    Amount: 4543434,
    ReceiverName: "NCC Ltd",
  },
  {
    Department: "Legal",
    Location: "Delhi",
    Amount: 3232243,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Legal",
    Location: "Delhi",
    Amount: 232325,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Legal",
    Location: "Delhi",
    Amount: 4435334,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Legal",
    Location: "Delhi",
    Amount: 434434,
    ReceiverName: "IDFC Finance Ltd",
  },
  {
    Department: "Legal",
    Location: "Delhi",
    Amount: 5343435,
    ReceiverName: "BHEL",
  },
  {
    Department: "HR",
    Location: "Mumbai",
    Amount: 4345354,
    ReceiverName: "BHEL",
  },
  { Department: "HR", Location: "Mumbai", Amount: 323232, ReceiverName: "IOL" },
  { Department: "HR", Location: "Mumbai", Amount: 533434, ReceiverName: "IOL" },
  {
    Department: "HR",
    Location: "Mumbai",
    Amount: 6453422,
    ReceiverName: "IOL",
  },
  {
    Department: "HR",
    Location: "Mumbai",
    Amount: 243453,
    ReceiverName: "Alpa Labs",
  },
  {
    Department: "Sales",
    Location: "Kochi",
    Amount: 5353433,
    ReceiverName: "Alpa Labs",
  },
  {
    Department: "Sales",
    Location: "Kochi",
    Amount: 3436353,
    ReceiverName: "Alpa Labs",
  },
  {
    Department: "Sales",
    Location: "Kochi",
    Amount: 343423,
    ReceiverName: "Alpa Labs",
  },
  {
    Department: "Sales",
    Location: "Kochi",
    Amount: 3533433,
    ReceiverName: "Alpa Labs",
  },
];

// Merge additional data into combinedData
additionalData.forEach((entry) => {
  combinedData.push({
    city: entry.Location,
    department: entry.Department,
    amount: entry.Amount,
    receiverName: entry.ReceiverName,
  });
});

// Chart variables
let combinedLineChart;
let combinedBarChart;
let combinedAreaChart;
let polarAreaChart;

// Function to render charts
function renderCombinedCharts(selectedCities, selectedDepartments) {
  const filteredData = combinedData.filter(
    (item) =>
      selectedCities.includes(item.city) &&
      selectedDepartments.includes(item.department)
  );

  // Prepare a list of unique receiver names across selected cities
  const allReceivers = [
    ...new Set(filteredData.map((item) => item.receiverName)),
  ];

  const groupedData = {};
  selectedCities.forEach((city) => {
    groupedData[city] = {};
    allReceivers.forEach((receiver) => {
      groupedData[city][receiver] = 0; // Initialize to 0
    });
  });

  // Sum amounts for each receiver in the filtered data
  filteredData.forEach((item) => {
    groupedData[item.city][item.receiverName] += item.amount; // Accumulate amounts
  });

  const lineSeries = Object.keys(groupedData).map((city) => ({
    name: city,
    data: allReceivers.map((receiver) => ({
      x: receiver,
      y: groupedData[city][receiver], // This will be 0 if there are no transactions
    })),
  }));

  // Initialize or update line chart
  if (!combinedLineChart) {
    combinedLineChart = new ApexCharts(
      document.querySelector("#combinedLineChart"),
      {
        chart: { type: "line", height: 300 },
        series: lineSeries,
        xaxis: { title: { text: "Receiver" } },
        yaxis: { title: { text: "Amount (₹)" }, min: 2500000 },
      }
    );
    combinedLineChart.render();
  } else {
    combinedLineChart.updateOptions({
      series: lineSeries,
    });
  }

  // Bar chart data preparation
  const barSeries = allReceivers.map((receiver) => ({
    name: receiver,
    data: selectedCities.map((city) => groupedData[city][receiver]),
  }));

  // Initialize or update bar chart
  if (!combinedBarChart) {
    combinedBarChart = new ApexCharts(
      document.querySelector("#combinedBarChart"),
      {
        chart: { type: "bar", height: 300 },
        series: barSeries,
        xaxis: { categories: selectedCities },
        yaxis: { title: { text: "Amount (₹)" }, min: 2500000 },
        dataLabels: {
          // Disable data labels
          enabled: false,
        },
      }
    );
    combinedBarChart.render();
  } else {
    combinedBarChart.updateOptions({
      series: barSeries,
      dataLabels: {
        // Disable data labels
        enabled: false,
      },
    });
  }

  // Area chart data preparation
  const areaSeries = allReceivers.map((receiver) => ({
    name: receiver,
    data: selectedCities.map((city) => groupedData[city][receiver]),
  }));

  // Initialize or update area chart
  if (!combinedAreaChart) {
    combinedAreaChart = new ApexCharts(
      document.querySelector("#combinedAreaChart"),
      {
        chart: { type: "area", height: 300 },
        series: areaSeries,
        xaxis: {
          categories: selectedCities,
          title: { text: "Cities" },
        },
        yaxis: { title: { text: "Amount (₹)" }, min: 2500000 },
        dataLabels: {
          enabled: false, // Disable data labels
        },
      }
    );
    combinedAreaChart.render();
  } else {
    combinedAreaChart.updateOptions({
      series: areaSeries,
    });
  }
  renderPolarAreaChart(filteredData, allReceivers);
}
// Function to render Polar Area Chart
function renderPolarAreaChart(filteredData, allReceivers) {
  const polarSeries = {};

  // Sum amounts for each receiver
  filteredData.forEach((item) => {
    if (!polarSeries[item.receiverName]) {
      polarSeries[item.receiverName] = 0;
    }
    polarSeries[item.receiverName] += item.amount; // Sum amounts
  });

  // Convert the object into arrays for ApexCharts
  const seriesData = Object.values(polarSeries);
  const categoriesData = Object.keys(polarSeries);

  // Initialize or update Polar Area Chart
  if (!polarAreaChart) {
    polarAreaChart = new ApexCharts(document.querySelector("#polarAreaChart"), {
      chart: {
        type: "polarArea",
        height: 300,
      },
      series: seriesData,
      labels: categoriesData,
      title: {
        text: "",
      },
      fill: {
        opacity: 0.8,
      },
      dataLabels: {
        enabled: true,
      },
    });
    polarAreaChart.render();
  } else {
    polarAreaChart.updateOptions({
      series: seriesData,
      labels: categoriesData,
    });
  }
}
// Toggle dropdown menus
document
  .getElementById("dropdownToggleCombined")
  .addEventListener("click", function () {
    document
      .getElementById("dropdownMenuCombined")
      .classList.toggle("open-box");
  });

document
  .getElementById("dropdownToggleCityCombined")
  .addEventListener("click", function () {
    document
      .getElementById("dropdownMenuCityCombined")
      .classList.toggle("open-box");
  });

// Event listeners for checkboxes
document
  .getElementById("dropdownMenuCityCombined")
  .addEventListener("change", updateCharts);
document
  .getElementById("dropdownMenuCombined")
  .addEventListener("change", updateCharts);

// Update charts based on selected checkboxes
function updateCharts() {
  const selectedCities = Array.from(
    document
      .getElementById("dropdownMenuCityCombined")
      .querySelectorAll("input:checked")
  ).map((input) => input.value);
  const selectedDepartments = Array.from(
    document
      .getElementById("dropdownMenuCombined")
      .querySelectorAll("input:checked")
  ).map((input) => input.value);

  renderCombinedCharts(selectedCities, selectedDepartments);
}

// Initial render with default selections
renderCombinedCharts(
  ["Mumbai", "Pune", "Goa", "Kochi", "Chennai"], // Adjust the default cities as needed
  ["Sales", "Marketing", "Branding", "Admin", "Legal", "HR"] // Adjust the default departments as needed
);
